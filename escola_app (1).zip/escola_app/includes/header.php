<?php if (!isset($mysqli)) { require_once __DIR__ . '/../config.php'; } ?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?php echo isset($tituloPagina) ? h($tituloPagina) . ' - Sistema Escolar' : 'Sistema Escolar'; ?></title>
<link rel="stylesheet" href="assets/style.css">
</head>
<body>
<header class="topo">
  <div class="topo-conteudo">
    <h1>📚 Sistema Escolar</h1>
    <nav>
      <a href="index.php">Início</a>
      <a href="alunos.php">Alunos</a>
      <a href="disciplinas.php">Disciplinas</a>
      <a href="notas.php">Lançar Notas</a>
      <a href="relatorio_aluno.php">Relatório por Aluno</a>
      <a href="relatorio_disciplina.php">Relatório por Disciplina</a>
    </nav>
  </div>
</header>
<main class="conteudo">
<?php if (!empty($mensagem)): ?>
  <div class="alerta <?php echo h($mensagemTipo ?? 'sucesso'); ?>"><?php echo h($mensagem); ?></div>
<?php endif; ?>
