</main>
<footer class="rodape">
  <p>Sistema Escolar &copy; <?php echo date('Y'); ?></p>
</footer>
</body>
</html>
